﻿namespace CAB.Models
{
    public class HitCounterResponse
    {
        public int Today { get; set; }
        public int CurrentMonth { get; set; }
        public int Total { get; set; }
    }
}
