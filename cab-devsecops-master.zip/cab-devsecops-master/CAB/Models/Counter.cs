﻿namespace CAB.Models
{
    public class Counter
    {
        public string SanctionIP { get; set; }
        public string SubmitIp { get; set; }
        public string SubmitBy { get; set; }
    }
}
