﻿namespace CAB.Models
{
    public class ExcelDataViewModel
    {
        public List<CabData>? tbl_CabData { get; set; }
    }
}
 